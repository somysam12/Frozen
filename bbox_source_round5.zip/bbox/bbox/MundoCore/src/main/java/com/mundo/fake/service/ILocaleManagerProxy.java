package com.mundo.fake.service;

import android.os.IBinder;
import android.os.LocaleList;

import java.lang.reflect.Method;

import black.android.app.BRILocaleManagerStub;
import black.android.os.BRServiceManager;
import com.mundo.fake.hook.BinderInvocationStub;
import com.mundo.fake.hook.MethodHook;

public class ILocaleManagerProxy extends BinderInvocationStub {
    public static final String TAG = "ILocaleManagerProxy";

    public ILocaleManagerProxy() {
        super(BRServiceManager.get().getService("locale"));
    }

    @Override
    protected void onBindMethod() {
        super.onBindMethod();
        // Swallow setApplicationLocales — requires CHANGE_CONFIGURATION which virtual
        // apps don't have; letting it reach the real service throws SecurityException.
        addMethodHook(new MethodHook() {
            @Override
            protected String getMethodName() { return "setApplicationLocales"; }
            @Override
            protected Object hook(Object who, Method method, Object[] args) {
                return null; // no-op, void return
            }
        });
        // Return empty LocaleList for getApplicationLocales — requires
        // READ_APP_SPECIFIC_LOCALES which virtual apps don't have.
        addMethodHook(new MethodHook() {
            @Override
            protected String getMethodName() { return "getApplicationLocales"; }
            @Override
            protected Object hook(Object who, Method method, Object[] args) {
                return LocaleList.getEmptyLocaleList();
            }
        });
    }

    @Override
    protected Object getWho() {
        return BRILocaleManagerStub.get().asInterface(BRServiceManager.get().getService("locale"));
    }

    @Override
    protected void inject(Object baseInvocation, Object proxyInvocation) {
        replaceSystemService("locale");
    }

    @Override
    public boolean isBadEnv() {
        return false;
    }
}
