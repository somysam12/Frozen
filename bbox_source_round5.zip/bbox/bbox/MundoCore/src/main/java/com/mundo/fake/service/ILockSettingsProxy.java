package com.mundo.fake.service;

import java.lang.reflect.Method;

import black.android.os.BRServiceManager;
import com.mundo.fake.hook.BinderInvocationStub;
import com.mundo.fake.hook.MethodHook;
import com.mundo.fake.hook.ProxyMethod;

/**
 * Intercepts ILockSettings Binder calls so GMS/Play Store's "Checking info..."
 * verification does not hang waiting on keyguard/trust state that a virtual
 * device cannot provide.
 */
public class ILockSettingsProxy extends BinderInvocationStub {
    private static final String LOCK_SETTINGS_SERVICE = "lock_settings";

    public ILockSettingsProxy() {
        super(BRServiceManager.get().getService(LOCK_SETTINGS_SERVICE));
    }

    @Override
    protected Object getWho() {
        try {
            Class<?> stubClass = Class.forName("com.android.internal.widget.ILockSettings$Stub");
            Method asInterface = stubClass.getDeclaredMethod("asInterface", android.os.IBinder.class);
            return asInterface.invoke(null, BRServiceManager.get().getService(LOCK_SETTINGS_SERVICE));
        } catch (Throwable t) {
            return BRServiceManager.get().getService(LOCK_SETTINGS_SERVICE);
        }
    }

    @Override
    protected void inject(Object baseInvocation, Object proxyInvocation) {
        replaceSystemService(LOCK_SETTINGS_SERVICE);
    }

    @Override
    public boolean isBadEnv() {
        return false;
    }

    @ProxyMethod("havePassword")
    public static class HavePassword extends MethodHook {
        @Override
        protected Object hook(Object who, Method method, Object[] args) throws Throwable {
            return false;
        }
    }

    @ProxyMethod("havePattern")
    public static class HavePattern extends MethodHook {
        @Override
        protected Object hook(Object who, Method method, Object[] args) throws Throwable {
            return false;
        }
    }

    @ProxyMethod("getCredentialType")
    public static class GetCredentialType extends MethodHook {
        @Override
        protected Object hook(Object who, Method method, Object[] args) throws Throwable {
            return 0; // CREDENTIAL_TYPE_NONE
        }
    }

    @ProxyMethod("isSecure")
    public static class IsSecure extends MethodHook {
        @Override
        protected Object hook(Object who, Method method, Object[] args) throws Throwable {
            return false;
        }
    }
}
