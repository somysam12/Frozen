package com.mundo.app;

import android.app.Activity;
import android.app.Application;
import android.app.Instrumentation;
import android.app.Service;
import android.app.job.JobService;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.ContextWrapper;
import android.content.ComponentName;
import android.content.ContentProviderClient;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.os.Binder;
import android.os.Build;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.Log;
import android.MetaCore.RemoteManager;
import android.webkit.WebView;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Security;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import black.android.app.ActivityThreadAppBindDataContext;
import black.android.app.BRActivity;
import black.android.app.BRActivityManagerNative;
import black.android.app.BRActivityThread;
import black.android.app.BRActivityThreadActivityClientRecord;
import black.android.app.BRActivityThreadAppBindData;
import black.android.app.BRActivityThreadNMR1;
import black.android.app.BRActivityThreadQ;
import black.android.app.BRContextImpl;
import black.android.app.BRLoadedApk;
import black.android.app.BRService;
import black.android.content.BRBroadcastReceiver;
import black.android.content.BRContentProviderClient;
import black.android.graphics.BRCompatibility;
import black.android.security.net.config.BRNetworkSecurityConfigProvider;
import black.com.android.internal.content.BRReferrerIntent;
import black.dalvik.system.BRVMRuntime;

import com.mundo.MundoCore;
import com.mundo.app.configuration.AppLifecycleCallback;
import com.mundo.app.dispatcher.AppServiceDispatcher;
import com.mundo.core.CrashHandler;
import com.mundo.core.GmsCore;
import com.mundo.core.IBActivityThread;
import com.mundo.core.VCore;
import com.mundo.core.VNative;
import com.mundo.core.env.BEnvironment;
import com.mundo.core.env.VirtualRuntime;
import com.mundo.utils.FileUtils;
import com.mundo.core.system.user.BUserHandle;
import com.mundo.entity.AppConfig;
import com.mundo.entity.am.ReceiverData;
import com.mundo.entity.pm.InstalledModule;
import com.mundo.fake.delegate.AppInstrumentation;
import com.mundo.fake.delegate.ContentProviderDelegate;
import com.mundo.fake.frameworks.BXposedManager;
import com.mundo.fake.hook.HookManager;
import com.mundo.fake.service.HCallbackStub;
import com.mundo.utils.Reflector;
import com.mundo.utils.Slog;
import com.mundo.utils.compat.ActivityManagerCompat;
import com.mundo.utils.compat.BuildCompat;
import com.mundo.utils.compat.ContextCompat;
import com.mundo.utils.compat.StrictModeCompat;
import org.lsposed.lsparanoid.Obfuscate;

@Obfuscate
public class BActivityThread extends IBActivityThread.Stub {
    public static final String TAG = "BActivityThread";
    private static final Object mConfigLock = new Object();
    private static volatile BActivityThread sBActivityThread;
    private AppConfig mAppConfig;
    private AppBindData mBoundApplication;
    private Application mInitialApplication;
    private final List<ProviderInfo> mProviders = new ArrayList<>();
    private final Handler mH = MundoCore.get().getHandler();

    public static class AppBindData {
        ApplicationInfo appInfo;
        Object info;
        String processName;
        List<ProviderInfo> providers;
    }

    public static boolean isThreadInit() {
        return sBActivityThread != null;
    }

    public static BActivityThread currentActivityThread() {
        if (sBActivityThread == null) {
            synchronized (BActivityThread.class) {
                if (sBActivityThread == null) {
                    sBActivityThread = new BActivityThread();
                }
            }
        }
        return sBActivityThread;
    }

    public static AppConfig getAppConfig() {
        synchronized (mConfigLock) {
            return currentActivityThread().mAppConfig;
        }
    }

    public static List<ProviderInfo> getProviders() {
        return currentActivityThread().mProviders;
    }

    public static String getAppProcessName() {
        if (getAppConfig() != null) return getAppConfig().processName;
        if (currentActivityThread().mBoundApplication != null) return currentActivityThread().mBoundApplication.processName;
        return null;
    }

    public static String getAppPackageName() {
        if (getAppConfig() != null) return getAppConfig().packageName;
        if (currentActivityThread().mInitialApplication != null) return currentActivityThread().mInitialApplication.getPackageName();
        return null;
    }

    public static Application getApplication() {
        return currentActivityThread().mInitialApplication;
    }

    public static int getAppPid() {
        return getAppConfig() == null ? -1 : getAppConfig().bpid;
    }

    public static int getBUid() {
        return getAppConfig() == null ? BUserHandle.AID_APP_START : getAppConfig().buid;
    }

    public static int getBAppId() {
        return BUserHandle.getAppId(MundoCore.getHostUid());
    }

    public static int getCallingBUid() {
        return getAppConfig() == null ? MundoCore.getHostUid() : getAppConfig().callingBUid;
    }

    public static int getUid() {
        return getAppConfig() == null ? -1 : getAppConfig().uid;
    }

    public static int getUserId() {
        return getAppConfig() == null ? 0 : getAppConfig().userId;
    }

    public void initProcess(AppConfig appConfig) {
        synchronized (mConfigLock) {
            if (this.mAppConfig != null && !this.mAppConfig.packageName.equals(appConfig.packageName)) {
                throw new RuntimeException("reject init process: " + appConfig.processName + ", this process is : " + this.mAppConfig.processName);
            }
            this.mAppConfig = appConfig;
            final IBinder iBinder = asBinder();
            try {
                iBinder.linkToDeath(new IBinder.DeathRecipient() {
                        @Override
                        public void binderDied() {
                            synchronized (BActivityThread.mConfigLock) {
                                try {
                                    iBinder.linkToDeath(this, 0);
                                } catch (RemoteException e) {
                                    // ignore
                                }
                                BActivityThread.this.mAppConfig = null;
                            }
                        }
                    }, 0);

            } catch (RemoteException ignored) { }
        }
    }

    public boolean isInit() {
        return this.mBoundApplication != null;
    }

    public Service createService(ServiceInfo serviceInfo, IBinder token) {
        if (!isInit()) bindApplication(serviceInfo.packageName, serviceInfo.processName);
        try {
            Service service = (Service) BRLoadedApk.get(this.mBoundApplication.info).getClassLoader().loadClass(serviceInfo.name).newInstance();
            Context context = MundoCore.getContext().createPackageContext(serviceInfo.packageName, Context.CONTEXT_INCLUDE_CODE | Context.CONTEXT_IGNORE_SECURITY);
            BRContextImpl.get(context).setOuterContext(service);
            BRService.get(service).attach(context, MundoCore.mainThread(), serviceInfo.name,token, this.mInitialApplication, BRActivityManagerNative.get().getDefault());
            ContextCompat.fix(context);
            if (GmsCore.isGoogleAppOrService(serviceInfo.packageName)) {
                try {
                    int uid = BActivityThread.getUserId();
                    File virtualDataDir = BEnvironment.getDataDir(serviceInfo.packageName, uid);
                    FileUtils.mkdirs(virtualDataDir);
                    Object svcLoadedApk = BRContextImpl.get(context).mPackageInfo();
                    if (svcLoadedApk != null) {
                        BRLoadedApk.get(svcLoadedApk)._set_mDataDir(virtualDataDir.getAbsolutePath());
                        BRLoadedApk.get(svcLoadedApk)._set_mDataDirFile(virtualDataDir);
                    }
                    BRContextImpl.get(context)._set_mDataDir(virtualDataDir);
                    BRContextImpl.get(context)._set_mDatabasesDir(
                            BEnvironment.getDataDatabasesDir(serviceInfo.packageName, uid));
                    BRContextImpl.get(context)._set_mCacheDir(
                            BEnvironment.getDataCacheDir(serviceInfo.packageName, uid));
                    BRContextImpl.get(context)._set_mFilesDir(
                            BEnvironment.getDataFilesDir(serviceInfo.packageName, uid));
                } catch (Throwable ignored) { }
            }
            service.onCreate();
            return service;
        } catch (Exception e) {
            throw new RuntimeException("Unable to create service " + serviceInfo.name, e);
        }
    }

    public JobService createJobService(ServiceInfo serviceInfo) {
        if (!isInit()) bindApplication(serviceInfo.packageName, serviceInfo.processName);
        try {
            JobService service = (JobService) BRLoadedApk.get(this.mBoundApplication.info).getClassLoader().loadClass(serviceInfo.name).newInstance();
            Context context = MundoCore.getContext().createPackageContext(serviceInfo.packageName, Context.CONTEXT_INCLUDE_CODE | Context.CONTEXT_IGNORE_SECURITY);
            BRContextImpl.get(context).setOuterContext(service);
            BRService.get(service).attach(context, MundoCore.mainThread(), serviceInfo.name,getActivityThread(), this.mInitialApplication, BRActivityManagerNative.get().getDefault());
            ContextCompat.fix(context);
            if (GmsCore.isGoogleAppOrService(serviceInfo.packageName)) {
                try {
                    int uid = BActivityThread.getUserId();
                    File virtualDataDir = BEnvironment.getDataDir(serviceInfo.packageName, uid);
                    FileUtils.mkdirs(virtualDataDir);
                    Object svcLoadedApk = BRContextImpl.get(context).mPackageInfo();
                    if (svcLoadedApk != null) {
                        BRLoadedApk.get(svcLoadedApk)._set_mDataDir(virtualDataDir.getAbsolutePath());
                        BRLoadedApk.get(svcLoadedApk)._set_mDataDirFile(virtualDataDir);
                    }
                    BRContextImpl.get(context)._set_mDataDir(virtualDataDir);
                    BRContextImpl.get(context)._set_mDatabasesDir(
                            BEnvironment.getDataDatabasesDir(serviceInfo.packageName, uid));
                    BRContextImpl.get(context)._set_mCacheDir(
                            BEnvironment.getDataCacheDir(serviceInfo.packageName, uid));
                    BRContextImpl.get(context)._set_mFilesDir(
                            BEnvironment.getDataFilesDir(serviceInfo.packageName, uid));
                } catch (Throwable ignored) { }
            }
            service.onCreate();
            service.onBind(null);
            return service;
        } catch (Exception e) {
            throw new RuntimeException("Unable to create JobService " + serviceInfo.name, e);
        }
    }

    public void bindApplication(final String packageName, final String processName) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            final ConditionVariable conditionVariable = new ConditionVariable();
            MundoCore.get().getHandler().post(() -> {
                handleBindApplication(packageName, processName);
                conditionVariable.open();
            });
            conditionVariable.block();
        } else {
            handleBindApplication(packageName, processName);
        }
    }

    public synchronized void handleBindApplication(String packageName, String processName) {
        if (isInit())
            return;
        try {
            CrashHandler.create();
        } catch (Throwable ignored) {
        }
        Binder.clearCallingIdentity();
        PackageInfo packageInfo = MundoCore.getBPackageManager().getPackageInfo(packageName, PackageManager.GET_PROVIDERS, BActivityThread.getUserId());
        ApplicationInfo applicationInfo = packageInfo.applicationInfo;
        // Clamp targetSdkVersion to R (30) so guest apps running in this virtual space
        // don't trigger PendingIntent FLAG_IMMUTABLE enforcement (Android 12+, API 31+).
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && applicationInfo.targetSdkVersion >= Build.VERSION_CODES.S) {
            applicationInfo.targetSdkVersion = Build.VERSION_CODES.R;
        }
        if (packageInfo.providers == null) {
            packageInfo.providers = new ProviderInfo[]{};
        }
        mProviders.addAll(Arrays.asList(packageInfo.providers));
        // Ensure all virtual data dirs (databases/, files/, cache/cronet/ etc.) exist.
        // ensureAppDirs is normally called at install time, but call it here too so dirs
        // are guaranteed on every launch (e.g. after data clear or first boot).
        if (GmsCore.isGoogleAppOrService(packageName)) {
            try { GmsCore.ensureAppDirs(packageName, BActivityThread.getUserId()); } catch (Throwable ignored) { }
        }
        Object boundApplication = BRActivityThread.get(MundoCore.mainThread()).mBoundApplication();
        Context packageContext = createPackageContext(applicationInfo);
        Object loadedApk = BRContextImpl.get(packageContext).mPackageInfo();
        if (loadedApk != null) {
            BRLoadedApk.get(loadedApk)._set_mSecurityViolation(false);
            BRLoadedApk.get(loadedApk)._set_mApplicationInfo(applicationInfo);
        }
        // NOTE: mDataDir / mDatabasesDir overrides CANNOT be applied here — JniHook is not
        // yet initialized (VNative.init() is called below). They are applied after VNative.init().
        int targetSdkVersion = applicationInfo.targetSdkVersion;
        if (targetSdkVersion < Build.VERSION_CODES.GINGERBREAD) {
            StrictMode.ThreadPolicy newPolicy = new StrictMode.ThreadPolicy.Builder(StrictMode.getThreadPolicy()).permitNetwork().build();
            StrictMode.setThreadPolicy(newPolicy);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (targetSdkVersion < Build.VERSION_CODES.N) {
                StrictModeCompat.disableDeathOnFileUriExposure();
            }
        }
        VirtualRuntime.setupRuntime(processName, applicationInfo);
        try {
            BRVMRuntime.get(BRVMRuntime.get().getRuntime()).setTargetSdkVersion(applicationInfo.targetSdkVersion);
        } catch (Throwable ignored) { }
        if (BuildCompat.isS()) {
            BRCompatibility.get().setTargetSdkVersion(applicationInfo.targetSdkVersion);
        }
        VNative.init(Build.VERSION.SDK_INT);
        // JniHook is now initialized — apply all LoadedApk / ContextImpl overrides here.
        if (loadedApk != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                BRLoadedApk.get(loadedApk)._set_mApplicationInfo(applicationInfo);
            }
            // On API 33, ContextImpl.getDataDir() ignores mDataDir and calls
            // LoadedApk.getDataDirFile() → new File(loadedApk.mDataDir).
            // Fix the root String field so every lazy-init dir (databases, cache, files)
            // resolves from the virtual sandbox path, not the real system GMS path.
            if (GmsCore.isGoogleAppOrService(packageName)) {
                try {
                    int uid = BActivityThread.getUserId();
                    File virtualDataDir = BEnvironment.getDataDir(packageName, uid);
                    FileUtils.mkdirs(virtualDataDir);
                    BRLoadedApk.get(loadedApk)._set_mDataDir(virtualDataDir.getAbsolutePath());
                    BRLoadedApk.get(loadedApk)._set_mDataDirFile(virtualDataDir);
                    // Also pre-populate the specific dir fields on packageContext so they are
                    // never lazily resolved through the now-fixed-but-not-yet-called getDataDir().
                    BRContextImpl.get(packageContext)._set_mDataDir(virtualDataDir);
                    BRContextImpl.get(packageContext)._set_mDatabasesDir(
                            BEnvironment.getDataDatabasesDir(packageName, uid));
                    BRContextImpl.get(packageContext)._set_mCacheDir(
                            BEnvironment.getDataCacheDir(packageName, uid));
                    BRContextImpl.get(packageContext)._set_mFilesDir(
                            BEnvironment.getDataFilesDir(packageName, uid));
                } catch (Throwable ignored) { }
            }
        }
        assert packageContext != null;
        VCore.get().enableRedirect(packageContext);
        AppBindData bindData = new AppBindData();
        bindData.appInfo = applicationInfo;
        bindData.processName = processName;
        bindData.info = loadedApk;
        bindData.providers = mProviders;
        if (boundApplication != null) {
            ActivityThreadAppBindDataContext activityThreadAppBindData = BRActivityThreadAppBindData.get(boundApplication);
            activityThreadAppBindData._set_instrumentationName(new ComponentName(bindData.appInfo.packageName, Instrumentation.class.getName()));
            activityThreadAppBindData._set_appInfo(bindData.appInfo);
            activityThreadAppBindData._set_info(bindData.info);
            activityThreadAppBindData._set_processName(bindData.processName);
            activityThreadAppBindData._set_providers(bindData.providers);
        }
        mBoundApplication = bindData;
        // ACTION 1: Register virtual LoadedApk in ActivityThread.mPackages and mResourcePackages
        // to prevent AOSP installProvider() from creating a secondary isolated PathClassLoader.
        try {
            Object mainThread = MundoCore.mainThread();
            Field mPackagesField = mainThread.getClass().getDeclaredField("mPackages");
            mPackagesField.setAccessible(true);
            android.util.ArrayMap<String, java.lang.ref.WeakReference<?>> mPkgMap =
                (android.util.ArrayMap<String, java.lang.ref.WeakReference<?>>) mPackagesField.get(mainThread);
            if (mPkgMap != null) {
                mPkgMap.put(mBoundApplication.appInfo.packageName, new java.lang.ref.WeakReference<>(loadedApk));
            }
            Field mResourcePackagesField = mainThread.getClass().getDeclaredField("mResourcePackages");
            mResourcePackagesField.setAccessible(true);
            android.util.ArrayMap<String, java.lang.ref.WeakReference<?>> mResPkgMap =
                (android.util.ArrayMap<String, java.lang.ref.WeakReference<?>>) mResourcePackagesField.get(mainThread);
            if (mResPkgMap != null) {
                mResPkgMap.put(mBoundApplication.appInfo.packageName, new java.lang.ref.WeakReference<>(loadedApk));
            }
        } catch (Throwable t) {
            Slog.e("BActivityThread", "Failed to cache virtual LoadedApk in ActivityThread", t);
        }
        //ssl适配
        if (BRNetworkSecurityConfigProvider.getRealClass() != null) {
            Security.removeProvider("AndroidNSSP");
            BRNetworkSecurityConfigProvider.get().install(packageContext);
        }
        Application application;
        try {
            onBeforeCreateApplication(packageName, processName, packageContext);
            application = makeApplicationCompat(loadedApk);
            // makeApplication() may return a cached Application instance. Ensure the
            // Application's ContextImpl also points to the virtual sandbox dirs.
            if (GmsCore.isGoogleAppOrService(packageName)) {
                try {
                    int uid = BActivityThread.getUserId();
                    File virtualDataDir = BEnvironment.getDataDir(applicationInfo.packageName, uid);
                    Context appBaseCtx = application.getBaseContext();
                    // Fix root LoadedApk.mDataDir in case a new LoadedApk was created internally
                    Object appLoadedApk = BRContextImpl.get(appBaseCtx).mPackageInfo();
                    if (appLoadedApk != null) {
                        BRLoadedApk.get(appLoadedApk)._set_mDataDir(virtualDataDir.getAbsolutePath());
                        BRLoadedApk.get(appLoadedApk)._set_mDataDirFile(virtualDataDir);
                    }
                    BRContextImpl.get(appBaseCtx)._set_mDataDir(virtualDataDir);
                    BRContextImpl.get(appBaseCtx)._set_mDatabasesDir(
                            BEnvironment.getDataDatabasesDir(applicationInfo.packageName, uid));
                    BRContextImpl.get(appBaseCtx)._set_mCacheDir(
                            BEnvironment.getDataCacheDir(applicationInfo.packageName, uid));
                    BRContextImpl.get(appBaseCtx)._set_mFilesDir(
                            BEnvironment.getDataFilesDir(applicationInfo.packageName, uid));
                } catch (Throwable ignored) { }
            }
            ContextCompat.fix(application);
            ContextCompat.fix((Context) BRActivityThread.get(MundoCore.mainThread()).getSystemContext());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && "com.tencent.mm:recovery".equals(processName)) {
                fixWeChatRecovery(mInitialApplication);
            }
            mInitialApplication = application;
            BRActivityThread.get(MundoCore.mainThread())._set_mInitialApplication(mInitialApplication);
            // ACTION 3: Merge all split APK DEX files into the primary ClassLoader before
            // providers are installed, so all Play Store classes share one ClassLoader identity.
            mergeSplitApksIfPresent(mInitialApplication, applicationInfo.sourceDir);
            List<ProviderInfo> providers;
            installProviders(mInitialApplication, bindData.processName, bindData.providers);
            try {
				fixAiLiaoPhoto(mInitialApplication);
			} catch (Throwable ignored) { }
            onBeforeApplicationOnCreate(packageName, processName, application);
            AppInstrumentation.get().callApplicationOnCreate(application);
            onAfterApplicationOnCreate(packageName, processName, application);
            HookManager.get().checkEnv(HCallbackStub.class);
        } catch (Throwable e) {
            Log.e("BActivityThread", "handleBindApplication: app init failed: " + e);
        }
    }
    
    private Application makeApplicationCompat(Object loadedApk) throws Throwable {
        // Android 13 (API 33) renamed makeApplication() to makeApplicationInner()
        String primary  = Build.VERSION.SDK_INT >= 33 ? "makeApplicationInner" : "makeApplication";
        String fallback = Build.VERSION.SDK_INT >= 33 ? "makeApplication" : "makeApplicationInner";
        Class<?> cls = loadedApk.getClass();
        try {
            java.lang.reflect.Method m = cls.getDeclaredMethod(primary, boolean.class, android.app.Instrumentation.class);
            m.setAccessible(true);
            return (Application) m.invoke(loadedApk, false, null);
        } catch (NoSuchMethodException e) {
            java.lang.reflect.Method m = cls.getDeclaredMethod(fallback, boolean.class, android.app.Instrumentation.class);
            m.setAccessible(true);
            return (Application) m.invoke(loadedApk, false, null);
        }
    }

    private void fixAiLiaoPhoto(Application application) throws Throwable {
		if (application.getPackageName().equals("com.mosheng")) {
			ClassLoader loader = AppInstrumentation.get().getDelegateAppClassLoader();
			Class fileProviderClass = loader.loadClass("androidx.core.content.FileProvider");
			Method parsePathStrategyMethod = fileProviderClass.getDeclaredMethod("getPathStrategy", Context.class, String.class);
			parsePathStrategyMethod.setAccessible(true);
			Object pathStrategy = parsePathStrategyMethod.invoke(null, application, "com.mosheng.provider");
			Field fieldAuthority = pathStrategy.getClass().getDeclaredField("mAuthority");
			fieldAuthority.setAccessible(true);
            String newAuthority = "files." + MundoCore.getHostPkg();
			fieldAuthority.set(pathStrategy, newAuthority);
		}
	}
    
    private void fixWeChatRecovery(Application app) {
        try {
            Field field = app.getClassLoader().loadClass("com.tencent.recovery.Recovery").getField("context");
            field.setAccessible(true);
            if (field.get(null) != null) {
                return;
            }
            field.set(null, app.getBaseContext());
        } catch (Throwable ignored) { }
    }

    public static Context createPackageContext(ApplicationInfo info) {
        try {
            return MundoCore.getContext().createPackageContext(info.packageName, Context.CONTEXT_INCLUDE_CODE | Context.CONTEXT_IGNORE_SECURITY);
        } catch (Exception ignored) {
            return null;
        }
    }
    
    public Object getPackageInfo() {
        return this.mBoundApplication.info;
    }
    
    private void installProviders(Context context, String processName, List<ProviderInfo> providers) {
        if (providers == null || mInitialApplication == null) return;
        // ACTION 2: Direct local ContentProvider instantiation using the guest's single ClassLoader.
        // This prevents AOSP installProvider() from creating an isolated secondary PathClassLoader
        // which causes the Dagger/Hilt EntryPoints.get() ClassCastException.
        ClassLoader targetCl = mInitialApplication.getClassLoader();
        Object mainThread = MundoCore.mainThread();
        for (ProviderInfo info : providers) {
            try {
                Class<?> providerClass = targetCl.loadClass(info.name);
                ContentProvider provider = (ContentProvider) providerClass.newInstance();
                final String pkgName = info.packageName;
                final Application app = mInitialApplication;
                Context isolatedContext = new ContextWrapper(app) {
                    @Override
                    public Context getApplicationContext() { return app; }
                    @Override
                    public ClassLoader getClassLoader() { return targetCl; }
                    @Override
                    public String getPackageName() { return pkgName; }
                    @Override
                    public String getOpPackageName() { return pkgName; }
                    @Override
                    public Object getSystemService(String name) { return app.getSystemService(name); }
                };
                provider.attachInfo(isolatedContext, info);
                registerLocalProviderToActivityThread(mainThread, info, provider);
            } catch (Throwable t) {
                Slog.e("BActivityThread", "Failed to install local provider: " + info.name, t);
            }
        }
        ContentProviderDelegate.init();
    }

    private void registerLocalProviderToActivityThread(Object mainThread, ProviderInfo info, ContentProvider provider) {
        try {
            Field mProviderMapField = mainThread.getClass().getDeclaredField("mProviderMap");
            mProviderMapField.setAccessible(true);
            android.util.ArrayMap mProviderMap = (android.util.ArrayMap) mProviderMapField.get(mainThread);
            Class<?> recordClass = Class.forName("android.app.ActivityThread$ProviderClientRecord");
            java.lang.reflect.Constructor<?>[] constructors = recordClass.getDeclaredConstructors();
            java.lang.reflect.Constructor<?> ctor = constructors[0];
            ctor.setAccessible(true);
            Method getICP = ContentProvider.class.getDeclaredMethod("getIContentProvider");
            getICP.setAccessible(true);
            android.content.IContentProvider transport = (android.content.IContentProvider) getICP.invoke(provider);
            Object record;
            if (ctor.getParameterTypes().length == 4) {
                String[] names = info.authority != null ? info.authority.split(";") : new String[0];
                record = ctor.newInstance(names, transport, provider, null);
            } else {
                record = ctor.newInstance(mainThread, info.authority != null ? info.authority.split(";") : new String[0], transport, null);
            }
            Class<?> keyClass = Class.forName("android.app.ActivityThread$ProviderKey");
            java.lang.reflect.Constructor<?> keyCtor = keyClass.getDeclaredConstructor(String.class, int.class);
            keyCtor.setAccessible(true);
            if (info.authority != null) {
                for (String auth : info.authority.split(";")) {
                    Object key = keyCtor.newInstance(auth, BActivityThread.getUserId());
                    mProviderMap.put(key, record);
                }
            }
        } catch (Throwable t) {
            Slog.w("BActivityThread", "Could not register to mProviderMap: " + info.name, t);
        }
    }

    public static void mergeSplitApksIfPresent(Application app, String appDirSource) {
        if (app == null || appDirSource == null) return;
        ClassLoader cl = app.getClassLoader();
        if (!(cl instanceof dalvik.system.BaseDexClassLoader)) return;
        File appDir = new File(appDirSource).getParentFile();
        if (appDir == null || !appDir.exists()) return;
        File[] files = appDir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.getName().endsWith(".apk") && !f.getAbsolutePath().equals(appDirSource)) {
                try {
                    Method addDexPathMethod = dalvik.system.BaseDexClassLoader.class.getMethod("addDexPath", String.class);
                    addDexPathMethod.setAccessible(true);
                    addDexPathMethod.invoke(cl, f.getAbsolutePath());
                    Slog.i("BActivityThread", "Merged split APK into primary ClassLoader: " + f.getName());
                } catch (Throwable t) {
                    Slog.e("BActivityThread", "Failed to addDexPath for: " + f.getName(), t);
                }
            }
        }
    }

    private Context wrapProviderContext(Context baseContext, ProviderInfo info) {
        final Application app = this.mInitialApplication;
        final String pkg = info.packageName;
        return new ContextWrapper(baseContext) {
            @Override
            public Context getApplicationContext() {
                return app != null ? app : super.getApplicationContext();
            }
            @Override
            public ClassLoader getClassLoader() {
                return app != null ? app.getClassLoader() : super.getClassLoader();
            }
            @Override
            public String getPackageName() {
                return pkg;
            }
            @Override
            public String getOpPackageName() {
                return pkg;
            }
        };
    }

    private ContentProvider extractLocalProvider(Object holder) {
        // ContentProviderHolder stores the local provider in mLocalProvider (API < 29) or
        // provider (API >= 29). Try both field names.
        String[] fieldNames = {"mLocalProvider", "localProvider", "provider"};
        for (String name : fieldNames) {
            try {
                Field f = holder.getClass().getDeclaredField(name);
                f.setAccessible(true);
                Object p = f.get(holder);
                if (p instanceof ContentProvider) return (ContentProvider) p;
            } catch (Throwable ignored) {}
        }
        return null;
    }

    private void patchProviderContext(ContentProvider provider, ProviderInfo info) {
        if (provider == null || mInitialApplication == null) return;
        try {
            final Application virtualApp = mInitialApplication;
            final ClassLoader targetCl = mInitialApplication.getClassLoader();
            final String pkgName = info.packageName != null ? info.packageName : mInitialApplication.getPackageName();

            Context wrapped = new ContextWrapper(mInitialApplication) {
                @Override
                public Context getApplicationContext() { return virtualApp; }
                @Override
                public ClassLoader getClassLoader() { return targetCl; }
                @Override
                public String getPackageName() { return pkgName; }
                @Override
                public String getOpPackageName() { return pkgName; }
            };

            Field mContextField = ContentProvider.class.getDeclaredField("mContext");
            mContextField.setAccessible(true);
            mContextField.set(provider, wrapped);
        } catch (Throwable t) {
            Slog.e(TAG, "patchProviderContext failed for " + info.name + ": " + t.getMessage());
        }
    }

    public static Context createIsolatedProviderContext(Context baseContext, Application virtualApp, ProviderInfo info) {
        if (virtualApp == null) return baseContext;
        final ClassLoader targetCl = virtualApp.getClassLoader();
        final String pkgName = info.packageName;
        return new ContextWrapper(virtualApp) {
            @Override public Context getApplicationContext() { return virtualApp; }
            @Override public ClassLoader getClassLoader() { return targetCl; }
            @Override public String getPackageName() { return pkgName; }
            @Override public String getOpPackageName() { return pkgName; }
            @Override public Object getSystemService(String name) { return virtualApp.getSystemService(name); }
        };
    }

    public static Object installProvider(Object mainThread, Context context, ProviderInfo providerInfo, Object holder) throws Throwable {
        Method installProvider = Reflector.findMethodByFirstName(mainThread.getClass(), "installProvider");
        if (installProvider != null) {
            installProvider.setAccessible(true);
            return installProvider.invoke(mainThread, context, holder, providerInfo, false, true, true);
        }
        return null;
    }
    
    public void loadXposed(Context context) {
        String vPackageName = getAppPackageName();
        String vProcessName = getAppProcessName();
        if (!TextUtils.isEmpty(vPackageName) && !TextUtils.isEmpty(vProcessName) && BXposedManager.get().isXPEnable()) {
            assert vPackageName != null;
            assert vProcessName != null;
            boolean isFirstApplication = vPackageName.equals(vProcessName);
            List<InstalledModule> installedModules = BXposedManager.get().getInstalledModules();
            for (InstalledModule installedModule : installedModules) {
                if (!installedModule.enable) {
                    continue;
                }
                try {
                  //  PineXposed.loadModule(new File(installedModule.getApplication().sourceDir));
                } catch (Throwable ignored) { }
            }
            try {
              //  PineXposed.onPackageLoad(vPackageName, vProcessName, context.getApplicationInfo(), isFirstApplication, context.getClassLoader());
            } catch (Throwable ignored) {
            }
        }
        if (RemoteManager.sHideXposed) {
            VNative.hideXposed();
        }
    }

    @Override
    public IBinder getActivityThread() {
        return BRActivityThread.get(MundoCore.mainThread()).getApplicationThread();
    }

    @Override
    public void bindApplication() {
        if (!isInit()) bindApplication(getAppPackageName(), getAppProcessName());
    }

    @Override
    public void stopService(Intent intent) {
        AppServiceDispatcher.get().stopService(intent);
    }

    @Override
    public void restartJobService(String selfId) {}

    @Override
    public IBinder acquireContentProviderClient(ProviderInfo providerInfo) {
        if (!isInit()) bindApplication(getAppConfig().packageName, getAppConfig().processName);
        for (String auth : providerInfo.authority.split(";")) {
            ContentProviderClient client = MundoCore.getContext().getContentResolver().acquireContentProviderClient(auth);
            IInterface iInterface = BRContentProviderClient.get(client).mContentProvider();
            if (iInterface != null) return iInterface.asBinder();
        }
        return null;
    }

    @Override
    public IBinder peekService(Intent intent) {
        return AppServiceDispatcher.get().peekService(intent);
    }

    @Override
    public void finishActivity(final IBinder token) {
        mH.post(() -> {
            Map<IBinder, Object> activities = BRActivityThread.get(MundoCore.mainThread()).mActivities();
            Object clientRecord = activities.get(token);
            if (clientRecord == null) return;
            Activity activity = getActivityByToken(token);
            while (activity.getParent() != null) activity = activity.getParent();
            int resultCode = BRActivity.get(activity).mResultCode();
            Intent resultData = BRActivity.get(activity).mResultData();
            ActivityManagerCompat.finishActivity(token, resultCode, resultData);
            BRActivity.get(activity)._set_mFinished(true);
        });
    }

    @Override
    public void handleNewIntent(final IBinder token, final Intent intent) {
        mH.post(() -> {
            Intent newIntent = BuildCompat.isLollipop_MR1() ? BRReferrerIntent.get()._new(intent, MundoCore.getHostPkg()) : intent;
            Object mainThread = MundoCore.mainThread();
            if (BRActivityThread.get(mainThread)._check_performNewIntents(null, null) != null) {
                BRActivityThread.get(mainThread).performNewIntents(token, Collections.singletonList(newIntent));
            } else if (BRActivityThreadNMR1.get(mainThread)._check_performNewIntents(null, null, false) != null) {
                BRActivityThreadNMR1.get(mainThread).performNewIntents(token, Collections.singletonList(newIntent), true);
            } else if (BRActivityThreadQ.get(mainThread)._check_handleNewIntent(null, null) != null) {
                BRActivityThreadQ.get(mainThread).handleNewIntent(token, Collections.singletonList(newIntent));
            }
        });
    }

    @Override
    public void scheduleReceiver(final ReceiverData data) {
        if (!isInit()) bindApplication();
        mH.post(() -> {
            try {
                Context baseContext = mInitialApplication.getBaseContext();
                ClassLoader cl = baseContext.getClassLoader();
                data.intent.setExtrasClassLoader(cl);
                BroadcastReceiver receiver = (BroadcastReceiver) cl.loadClass(data.activityInfo.name).newInstance();
                BRBroadcastReceiver.get(receiver).setPendingResult(data.data.build());
                receiver.onReceive(baseContext, data.intent);
                BroadcastReceiver.PendingResult finish = BRBroadcastReceiver.get(receiver).getPendingResult();
                if (finish != null) finish.finish();
                MundoCore.getBActivityManager().finishBroadcast(data.data);
            } catch (Throwable ignored) { }
        });
    }

    public static Activity getActivityByToken(IBinder token) {
        Map<IBinder, Object> map = BRActivityThread.get(MundoCore.mainThread()).mActivities();
        return BRActivityThreadActivityClientRecord.get(map.get(token)).activity();
    }

    private void onBeforeCreateApplication(String packageName, String processName, Context context) {
        for (AppLifecycleCallback cb : MundoCore.get().getAppLifecycleCallbacks()) {
            cb.beforeCreateApplication(packageName, processName, context, getUserId());
        }
    }

    private void onBeforeApplicationOnCreate(String packageName, String processName, Application app) {
        for (AppLifecycleCallback cb : MundoCore.get().getAppLifecycleCallbacks()) {
            cb.beforeApplicationOnCreate(packageName, processName, app, getUserId());
        }
    }

    private void onAfterApplicationOnCreate(String packageName, String processName, Application app) {
        for (AppLifecycleCallback cb : MundoCore.get().getAppLifecycleCallbacks()) {
            cb.afterApplicationOnCreate(packageName, processName, app, getUserId());
        }
    }
}
